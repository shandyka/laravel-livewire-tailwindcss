<?php

namespace App\Livewire;

use Livewire\Component;

class NavigasiAtas extends Component
{
    public function render()
    {
        return view('livewire.navigasi-atas');
    }
}
